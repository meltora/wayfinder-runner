{"name":"conformance-fixture","version":"1.0.0","description":"Agent Pack format 2 conformance fixture"}
